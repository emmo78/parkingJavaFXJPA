package application;
import java.io.IOException;
import controleur.ControleurParking;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
/**
 * class MainCarteSalarie est la classe qui permet d'initialiser la boite de dialogue pour l'ajout d'une carte salarie.
 * 
 * @author Olivier Morel S�bastien SUDRON
 * @version 1.0
 */
public class MainCarteSalarie {
	private Stage primaryStage; 
	
	
	public MainCarteSalarie(Stage stage) {
		primaryStage = stage;
	}

	public void vueCarteSalarie() {
		try {
			FXMLLoader loader = new FXMLLoader();
			//System.out.println("test"+loader);
			//GridPane page = loader.load(getClass().getResource("../vue/VueCarteSalarie.fxml"));
			
			loader.setLocation(ControleurParking.class.getResource("/vue/VueCarteSalarie.fxml")); 
			GridPane page = (GridPane)loader.load();
			Scene scene = new Scene(page);

			 
// Cr�ation du formulaire comme fen�tre modele.			 
			Stage dialogStage = new Stage();
			dialogStage.setTitle("Ajouter Carte Salarie");
			dialogStage.initModality(Modality.WINDOW_MODAL);
			dialogStage.initOwner(primaryStage);
			
			dialogStage.setScene(scene); 
// La m�thode suivante montre le formulaire puis attend que l'utilisateur le ferme.
// Fermeture effectu�e dans le contr�leur du formulaire lorsque l'utilisateur clique
// sur un des 2 boutons.			
			dialogStage.showAndWait();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}