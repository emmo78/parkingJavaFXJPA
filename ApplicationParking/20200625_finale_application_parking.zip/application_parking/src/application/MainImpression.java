package application;

import java.io.IOException;

/**
 * Cette classe sert a lancer la fenetre et le controleur de l'impression.
 * 
 * @author S�bastien SUDRON
 * 
 */

import controleur.ControleurImpression;
import controleur.ControleurParking;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Carte;
import model.Cartesalarie;
/**
 * class MainImpression est la classe qui permet d'afficher la fenetre d'impression d'une carte
 * 
 * @author Olivier Morel S�bastien SUDRON
 * @version 1.0
 */

public class MainImpression {
	
	/**
	 * Constructeur, prend en argument un objet de type Stage. Il est appel� dans la
	 * classe MainParking pour instancier un objet de type MainImpression et lui
	 * transmettre un objet de type Stage la r�f�rence primaryStage,
	 * la fen�tre principale.
	 * 
	 * @param stage
	 */
	 
		private Stage primaryStage;
		
		public MainImpression(Stage stage){
			
			primaryStage = stage;
		}
		
		/**
		 * Charge la vue et son controleur et place la vue dans une sc�ne elle m�me plac�e
	     * dans la fenetre secondaire, la fenetre principale �tant le primaryStage.
		 */
		
		public void montrerLaCarteParking(Carte carte) {
			try {
				FXMLLoader loader = new FXMLLoader();
				loader.setLocation(ControleurParking.class.getResource("/vue/CarteParking.fxml"));
				GridPane page = (GridPane) loader.load();
				
				
	// Cr�ation du formulaire comme fen�tre modele.
				Stage dialogStage = new Stage();
				ControleurImpression  controleur = loader.getController();
				controleur.setCarte(carte);
				
				dialogStage.setTitle("Carte Parking ");
				dialogStage.initModality(Modality.WINDOW_MODAL);
				dialogStage.initOwner(primaryStage);
				
			
				
				Scene scene = new Scene(page);
				
				
				
				dialogStage.setScene(scene);
				
				
	// La m�thode suivante montre le formulaire puis attend que l'utilisateur le ferme.
	// Fermeture effectu�e dans le contr�leur du formulaire lorsque l'utilisateur clique
	// sur un des 2 boutons.
				dialogStage.showAndWait();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
