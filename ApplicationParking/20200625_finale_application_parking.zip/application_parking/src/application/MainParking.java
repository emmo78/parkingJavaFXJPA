package application;

import controleur.ControleurParking;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;

/**
 * class main la class principale qui lance l'aplication, c'est le point
 * d'entr�e de l'application
 * 
 * @author S�bastien SUDRON, Olivier MOREL
 * @version 1.0
 */
public class MainParking extends Application {

	/**
	 * Lanc�e par la classe Application qui lui transmet en argument la r�f�rence de
	 * l'objet de type Stage, fenetre principale de l'application. Puis elle charge
	 * le layout racine et son controleur, place le layout dans une sc�ne puis dans
	 * la fenetre primaryStage et la montre. Par ailleurs instancie des objets de
	 * type de classe chargeant un layout et d�f�nissant une fenetre. Ces objets ont
	 * comme attribut la r�f�rence de l'objet primaryStage. Et les r�f�rences de ces
	 * objets sont transmises au controleur
	 * 
	 */
	@Override
	public void start(Stage primaryStage) {
		try {

			FXMLLoader loader = new FXMLLoader();

			loader.setLocation(MainParking.class.getResource("/vue/VueParking.fxml"));
			GridPane root = (GridPane) loader.load();
			Scene scene = new Scene(root);
			primaryStage.setTitle("Application Parking");
			primaryStage.setScene(scene);
			primaryStage.show();

			ControleurParking controleur = loader.getController();
			controleur.setMainCarteSalarie(new MainCarteSalarie(primaryStage));
			controleur.setMainSimulateur(new MainSimulateur(primaryStage));
			controleur.setMainImpression(new MainImpression(primaryStage));

		} catch (Exception e) {

			e.printStackTrace();

		}
	}

	/**
	 * Point d'entr�e de l'application, lance Application.launch(), le point
	 * d'entr�e pour les applications javaFX
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		launch(args);
	}
}
