package application;

import java.io.IOException;

import controleur.ControleurParking;
import controleur.ControleurSaisieIdCarte;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * Cette classe sert � lancer la fenetre et le contr�leur de la fenetre de
 * saisie du num�ro de la carte
 * 
 * @author Olivier MOREL
 *
 */
public class MainSaisieIdCarte {
	private Stage stage;

	/**
	 * Constructeur, prend en argument un objet de type Stage. Il est appel� dans la
	 * classe MainSimulateur pour instancier un objet de type MainSaisieIdCarte et
	 * lui transmettre un objet de type Stage en l'occurence la r�f�rence de la
	 * fen�tre du simulateur.
	 * 
	 * @param stage
	 */
	public MainSaisieIdCarte(Stage stage) {
		this.stage = stage;
	}

	/**
	 * Charge la vue et son controleur, place la vue dans une sc�ne elle m�me plac�e
	 * dans la fenetre secondaire, la fenetre principale �tant le stage. Elle re�oit
	 * en argument la r�f�rence du controleurParking instanci� en cours.
	 * 
	 * @param controleurParking
	 */
	public void vueSaisieIdCarte(ControleurParking controleurParking) {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(ControleurParking.class.getResource("/vue/VueSaisieIdCarte.fxml"));
			GridPane root = (GridPane) loader.load();
			ControleurSaisieIdCarte controleurSaisieIdCarte = loader.getController();
			controleurSaisieIdCarte.setControleurParking(controleurParking);

			Stage stage = new Stage();
			stage.setTitle("Simulateur");
			stage.initModality(Modality.WINDOW_MODAL);
			stage.initOwner(this.stage);

			stage.setScene(new Scene(root));
			stage.showAndWait();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
