package application;

import java.io.IOException;

import controleur.ControleurParking;
import controleur.ControleurSimulateur;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * Cette classe sert � lancer la fenetre et le contr�leur du simulateur
 * 
 * @author Olivier MOREL
 *
 */
public class MainSimulateur {
	private Stage stage;

	/**
	 * Constructeur, prend en argument un objet de type Stage. Il est appel� dans la
	 * classe MainParking pour instancier un objet de type MainSimulateur et lui
	 * transmettre un objet de type Stage en l'occurance la r�f�rence primaryStage,
	 * la fen�tre principale.
	 * 
	 * @param stage
	 */
	public MainSimulateur(Stage stage) {
		this.stage = stage;
	}

	/**
	 * Charge la vue et son controleur, place la vue dans une sc�ne elle m�me plac�e
	 * dans la fenetre secondaire, la fenetre principale �tant le primaryStage. De
	 * meme, instancie un objet de type MainSaisieIdCarte et invoque son
	 * constructeur en transmettant en argument la r�f�recne sur la fenetre. Puis
	 * elle transmet la r�f�rence de cette objet � l'attribut correspondant du
	 * controleur. Elle re�oit en argument la r�f�rence du controleurParking
	 * instanci� en cours.
	 * 
	 * @param controleurParking
	 */
	public void vueSimulateur(ControleurParking controleurParking) {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(ControleurParking.class.getResource("/vue/VueSimulateur.fxml"));
			GridPane root = (GridPane) loader.load();
			
			ControleurSimulateur controleurSimulateur = loader.getController();
			controleurSimulateur.setControleurParking(controleurParking);
	 
			Stage simulStage = new Stage();
			simulStage.setTitle("Simulateur");
			simulStage.initModality(Modality.NONE);
			simulStage.initOwner(stage);
			
			MainSaisieIdCarte mainSaisieIdCarte = new MainSaisieIdCarte(simulStage);
			controleurSimulateur.setMainSaisieIdCarte(mainSaisieIdCarte);
			
			simulStage.setScene(new Scene(root));
			simulStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
