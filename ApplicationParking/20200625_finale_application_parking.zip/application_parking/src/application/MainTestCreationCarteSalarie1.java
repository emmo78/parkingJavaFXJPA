package application;

import model.Cartesalarie;
import dao.CartesalarieDAO;

public class MainTestCreationCarteSalarie1 {

	public static void main(String[] args) {
		//ControleurParking controleurParking = new ControleurParking();
		
		/*String departement="78";
		String nom =" Martin";
	ajouterCarteSalarie(departement, nom);*/
	
	 String  departement = "77";

	 String nom = "Tintin";

		Cartesalarie carteSal1 = new Cartesalarie(departement, nom);
		
		CartesalarieDAO controleurParking = new CartesalarieDAO();

		controleurParking.creerCarte(carteSal1);
		
		System.out.println(carteSal1);

	}
	
	

}
