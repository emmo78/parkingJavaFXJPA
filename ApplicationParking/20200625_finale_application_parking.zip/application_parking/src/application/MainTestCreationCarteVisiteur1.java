package application;

import java.util.Date;
import java.util.List;

import controleur.ControleurParking;
import dao.CarteDAO;
import dao.CartevisiteurDAO;
import dao.ParkingDAO;
import model.Carte;
import model.Cartevisiteur;

public class MainTestCreationCarteVisiteur1 {

	public static void main(String[] args) {
		
		Date dateEntree = new Date(); Date dateSortie=null;Cartevisiteur
		carteVisiteur = new Cartevisiteur(dateEntree,dateSortie);

		Cartevisiteur carteVisit1 = new Cartevisiteur(dateEntree, dateSortie);

		CarteDAO visiteurDAO = new CartevisiteurDAO();

		ControleurParking controleurParking = new ControleurParking();
		
		ParkingDAO parkingDAO = new ParkingDAO();

		// Cartevisiteur test=controleurParking.dmdeCreatCVsiteur();

		// System.out.println(carteVisit1);

		List<Carte> listLescartesVisteurs = visiteurDAO.voirLesCartes();

		/*
		 * 
		 * 
		 * visiteurDAO.CreerCarteVisiteur(carteVisiteur);
		 */

		System.out.println(listLescartesVisteurs);
		// System.out.println(carteVisiteur);
		
		//System.out.println(     parkingDAO.));
		 System.out.println(   parkingDAO.voirLesPlaceDeParkingVisiteur());
		 
		controleurParking.dmdeCreatCVsiteur();

	}

}

