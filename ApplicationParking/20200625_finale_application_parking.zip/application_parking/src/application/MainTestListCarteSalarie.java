package application;

import java.util.List;

import dao.CartesalarieDAO;
import dao.ParkingDAO;
import model.Carte;
import model.Parking;

public class MainTestListCarteSalarie {

	public static void main(String[] args) {

		ParkingDAO parkingDao = new ParkingDAO();
		CartesalarieDAO carteSal = new CartesalarieDAO();

		List<Carte> listCarteSalarie = carteSal.voirLesCartes();

		 
	}

}

