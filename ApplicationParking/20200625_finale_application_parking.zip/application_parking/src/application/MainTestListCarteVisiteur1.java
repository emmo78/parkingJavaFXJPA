package application;

import java.util.List;

import controleur.ControleurParking;
import dao.CartevisiteurDAO;
import dao.ParkingDAO;
import model.Carte;


public class MainTestListCarteVisiteur1 {

	public static void main(String[] args) {
		
		ParkingDAO parkingDao = new ParkingDAO();
		CartevisiteurDAO carteVisi = new CartevisiteurDAO();
		ParkingDAO parkingDAO = new ParkingDAO(); 
		
		ControleurParking controleurParking = new ControleurParking();
		
		boolean nombreDePlaceVisteurDispo =controleurParking.veriPlaceDispoVisiteur();
		int nombreDePlaceDispo=   parkingDAO.voirLesPlaceDeParkingVisiteur()-controleurParking.veriNombreCartesVisiteursEnCour();
		
		List<Carte> listCarteVisiteur = carteVisi.voirLesCartes() ;
		
		
	System.out.println("Place du parking avant action: "+ parkingDao.voirLesPlaceDeParkingAttribue());
		
		System.out.println(listCarteVisiteur);
		System.out.println("je cr�e une carte visiteur ");
		
		// controleurParking.dmdeCreatCVsiteur(); 
		System.out.println("place visteur disponible " +nombreDePlaceVisteurDispo );
		
		int nbr= controleurParking.veriNombreCartesVisiteursEnCour();
		System.out.println("nombre de carte visiteur en cours "+ nbr);
		
 		
		
		System.out.println( "nombre de  place Visiteur" + parkingDAO.voirLesPlaceDeParkingVisiteur());
		
		
		
		System.out.println("nombre de place visiteur disponible "+nombreDePlaceDispo);
		
		
		
		
	}

}