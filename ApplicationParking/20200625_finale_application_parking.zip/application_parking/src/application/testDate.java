package application;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneOffset;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import model.Cartevisiteur;

public class testDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("application_parking");
		EntityManager em = factory.createEntityManager();
		Cartevisiteur cartevisiteur;
		
		long date = LocalDate.now().toEpochDay()*24*3600*1000; // count of days where day 0 is 1970-01-01 (ISO)
		long time = LocalTime.now().toSecondOfDay()*1000;
		System.out.println("date en ms : "+date+"\ntime en ms : "+time);
		long dateTime = date+time;
		
		Date sqlDate = new Date(dateTime);
		long sqlDatems = sqlDate.getTime();
		
		System.out.println(LocalDateTime.ofEpochSecond(sqlDatems/1000L, 0, ZoneOffset.of("Z")));
		
/*		em.getTransaction().begin();
		cartevisiteur = em.find(Cartevisiteur.class, 109);
		cartevisiteur.setDateSortie(sqlDate);
		em.getTransaction().commit();*/
		
		cartevisiteur=null;
				
		em.getTransaction().begin();
		cartevisiteur = em.find(Cartevisiteur.class, 109);
		em.getTransaction().commit();
		
		sqlDatems = cartevisiteur.getDateSortie().getTime();
		System.out.print(LocalDateTime.ofEpochSecond(sqlDatems/1000L, 0, ZoneOffset.of("Z")));
		System.out.print(cartevisiteur.vuCarteHistorique());		
	}

}
