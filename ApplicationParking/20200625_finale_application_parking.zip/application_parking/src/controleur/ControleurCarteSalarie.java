package controleur;

import dao.CarteDAO;
import dao.CartesalarieDAO;
import dao.ParkingDAO;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Carte;
import model.Cartesalarie;

/**
 * Pour l'acc�s aux donn�es des cartes salari�s
 * 
 * @author Djafri, Tangara, Morel, Sudron
 *
 */
public class ControleurCarteSalarie {

	private ControleurParking controleurParking;
	private ParkingDAO parkingDAO;
	private CarteDAO carteSalarieDAO;

	public ControleurCarteSalarie() {

		controleurParking = new ControleurParking();
		parkingDAO = new ParkingDAO();
		carteSalarieDAO = new CartesalarieDAO();
	}

	@FXML
	private TextField nom;

	@FXML
	private TextField departement;

	/**
	 * attribut FXML de type bouton boutonValiderAjouterAuteur qui permet de valider
	 * la creation de la carte salari� et de fermer la boite de dialogue
	 */
	@FXML
	private Button boutonValiderAjouterCarteSalarie;

	/**
	 * attribut FXML de type bouton boutonAnnulerAjouterSalarie qui permet d'annuler
	 * la creation de l'auteur
	 */
	@FXML
	private Button boutonAnnulerAjouterSalarie;

	/**
	 * methode qui permet d'annuler l'ajout de l'auteur et de fermer la boite de
	 * dialogue
	 */

	@FXML
	private void annulerAjouterSalarie() {

		Stage dialogStage = (Stage) boutonAnnulerAjouterSalarie.getScene().getWindow();

		dialogStage.close();

	}

	/**
	 * methode controle de saisie du champs nom
	 * 
	 * @return false or true
	 */

	private boolean ControleNomSalarie() {
		String Nom = nom.getText();
		if (Nom.length() < 1 || Nom.length() > 50) {

			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Probl�me sur le nom du salari� ");
			alert.setHeaderText("Erreur de saisie sur le nom");
			if (Nom.length() < 1)
				nom.setText("le nom ne peut pas �tre vide");

			if (Nom.length() > 25)
				nom.setText("le nom doit comport� moins de 50 caract�res");

			alert.showAndWait();
			return false;
		} else
			return true;
	}
	
	/**
	 * methode controle de saisie du champs departement
	 * 
	 * @return false or true
	 */

	private boolean ControleDepartement() {
		String Departement = departement.getText();
		if (Departement.length() < 1 || Departement.length() > 3) {

			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Probl�me sur le nom du departement");
			if (Departement.length() < 1)
				departement.setText("le d�partement ne peut pas �tre vide");

			if (Departement.length() > 5)
				departement.setText("le d�partement doit comport� moins de 6 caract�res");

			alert.showAndWait();
			return false;
		} else
			return true;
	}

	/**
	 * Methode qui permet de faire une demande de nouvelle carte salarie la methode
	 * va verifier qu'il ai bien une place visiteur disponible dans ce cas une place
	 * reserv� visiteur sera dr�crement� et une nouvelle place reserv� salari� sera
	 * incr�ment�
	 * 
	 */

	@FXML
	private void dmdeCreatCSlarie() {

		// MainCarteSalarie mainCarteSalarie = new MainCarteSalarie(primaryStage);

		if (controleurParking.veriPlaceDispoSalarie()) {

			if (ControleNomSalarie()&&ControleDepartement()) {

				String Departement = departement.getText();
				String Nom = nom.getText();
				Carte carteSal = new Cartesalarie(Departement, Nom);
				carteSalarieDAO.creerCarte(carteSal);
				Stage dialogStage = (Stage) boutonValiderAjouterCarteSalarie.getScene().getWindow();
				dialogStage.close();

			}
		}
	}

}
