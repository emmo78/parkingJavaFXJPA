package controleur;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Formatter;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import model.Carte;
import model.Cartesalarie;

public class ControleurImpression {
	/**
	 * class controleur Impression permet de lancer l'impression d'un carte parking
	 * 
	 * @author S�bastien SUDRON
	 * @version 1.0
	 */

	/**
	 * Attribut pour la carte visiteur parking
	 */

	private String carteParkingVisteur = "Carte parking visiteur";

	/**
	 * Attribut pour la carte visiteur salarie
	 */

	private String carteParkingSalarie = "Carte parking Salari�";

	/**
	 * attibue objet de type carte
	 */

	private Carte carte;

	/**
	 * constructeur sans argument du ControleurImpression
	 */

	public ControleurImpression() {

	}

	/**
	 * attribut fxml Id pour id salarie numero de carte salarie ou id visisteur
	 * 
	 */

	@FXML
	private Label Id;

	/**
	 * attibut FXML du Label champ1a titre nom ou dateEntree visiteur
	 */

	@FXML
	private Label Champs1a;

	/**
	 * attibut FXML du Label champ2a titre d�partement
	 * 
	 */

	/**
	 * attribut fxml date entree visiteur ou le nom salarie
	 */

	@FXML
	private Label Champs1b;

	/**
	 * attribut fxml titre departement si carte salarie
	 */

	@FXML

	private Label Champs2a;

	/**
	 * attribut fxml departement du salari� si carte salarie
	 */

	@FXML
	private Label Champs2b;

	/**
	 * attribut fxml typecarte salarieou visiteur
	 * 
	 * @param carte
	 */
	@FXML
	private Label TypeCarte;
	
	/**
	 * attribut fxml DateEntree carte sortie
	 * @param carte
	 */
	@FXML
	private Label DateEntree;
	
	/**
	 * Methode qui permet de charger un objet carte dans la fen�tre de dialogue d�di� � l'impression
	 * en fonction du type de carte charg� en param�tre visiteur ou salari�
	 * 
	 * @param carte
	 */
	
	public void setCarte(Carte carte) {

		this.carte = carte;

		if (carte != null) {

			if (carte.getId() > 100) {
				TypeCarte.setText(carteParkingVisteur);
				
				 
				String numId = Integer.toString(carte.getId());
				Id.setText("N� "+numId); 
				
			
							
				String dateEntreeVisiteur = LocalDateTime.ofEpochSecond(carte.getDateEntree().getTime()/1000, 0, ZoneOffset.of("Z")).format(DateTimeFormatter.ofPattern("dd/MM/yyyy - HH:mm:ss"));
				
				DateEntree.setText(dateEntreeVisiteur);

				Champs1a.setText("");
				Champs1b.setText("");
				Champs2a.setText("");
				Champs2b.setText("");
			}

			if (carte.getId() < 100) {
				TypeCarte.setText(carteParkingSalarie);
				String numId = Integer.toString(carte.getId());
				
				
				Id.setText("N� "+numId);
				Champs1a.setText("nom");
				Champs1b.setText(carte.getNom());
				Champs2a.setText("Departement");
				Champs2b.setText(carte.getDepartement());
				DateEntree.setText("");

			}

		}

	}
}
