package controleur;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import application.MainCarteSalarie;
import application.MainImpression;
import application.MainSaisieIdCarte;
import application.MainSimulateur;
import dao.CarteDAO;
import dao.CartesalarieDAO;
import dao.CartevisiteurDAO;
import dao.ParkingDAO;
import model.Carte;

import model.Cartevisiteur;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;

import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import vue.Barriere;
import vue.BarriereEntrer;
import vue.BarriereSortir;
import vue.Capteur;
import vue.CapteurEntrer;
import vue.CapteurSortir;
import vue.Indicateur;
import vue.LecteurCarte;
import vue.LecteurEntrer;
import vue.LecteurSortir;

/**
 * Cette classe contient la logique concernant les actions effectu�es par le
 * gestionnaire de parking et aussi les cas d'utilisation entr�e et sortir
 * 
 * 
 * @author Sebastien SUDRON, Olivier MOREL
 *
 */

public class ControleurParking {

	private int nombreDePlaceVisiteur;
	private int nombreDePlaceSalarie;
	private int nombreDeCartesVisiteursEnCours;
	private int nombreDePlaceDispo;
	private int nombreDePlaceParking;
	private Capteur capteurEntrer;
	private Capteur capteurSortir;
	private LecteurCarte lecteurCarteEntrer;
	private LecteurCarte lecteurCarteSortir;
	private int idCarte;
	private Barriere barriereEntrer;
	private Barriere barriereSortir;
	private Indicateur indicateur;
	private String indiquateurParking;

	/**
	 * attribut dao Carte Salarie
	 * 
	 */
	private CarteDAO carteSalarieDAO;

	/**
	 * attribut dao Carte Visiteur
	 * 
	 */
	private CarteDAO carteVisiteurDAO;

	/**
	 * Label nombde de place place parking salarie en cours
	 */
	@FXML
	private Label nombreTotalPlaceSalarieEncours;

	/**
	 * label nombre totale de place du parking
	 */
	@FXML
	private Label nombreTotalPlaceParking;

	/**
	 * label nombre totale de place salarie
	 */
	@FXML
	private Label nombreTotalPlaceSalarie;

	/**
	 * label nombre totale de place visteur
	 */
	@FXML
	private Label nombreTotalPlaceVisiteur;

	/**
	 * label nombre de visiteur en cours
	 */
	@FXML
	private Label nombreTotalvisiteurEnCours;

	/**
	 * label etat du parking visiteur => place dispo ou complet
	 */
	@FXML
	private Label etatParkingVisiteur;

	/**
	 * label attribut departement du salarie
	 */
	@FXML
	private TextField departement;

	/**
	 * attribut qui designe le Nom du salarie
	 */
	@FXML
	private TextField nom;

	/**
	 * Liste des Cartes salaries en cours
	 */
	@FXML
	private ListView<Carte> lesCartesSalaries;

	/**
	 * Liste des Cartes visiteurs en cours
	 */

	private ParkingDAO parkingDAO;

	private MainCarteSalarie mainCarteSalarie; // = new MainCarteSalarie(primaryStage)

	private MainImpression mainImpression;
	
	/**
	 * observable liste des salaries qui alimente la liste view salarie
	 */
	private ObservableList<Carte> observableListeCartesSalaries = FXCollections.observableArrayList();

	@FXML
	private ListView<String> lesCartesVisiteursHistorique;
	
	/**
	 * observable liste des visiteur qui alimente la liste view visiteur historique
	 */
	private ObservableList<String> observableListeCartesVisteursHistorique = FXCollections.observableArrayList();

	@FXML
	private ListView<Carte> lesCartesVisiteursEnCours;

	/**
	 * observable liste des visiteurs qui alimente la liste view visiteur en cours
	 */
	private ObservableList<Carte> observableListeCartesVisteursEnCours = FXCollections.observableArrayList();

	/**
	 * Pour et utilis�s par le simulateur : l'attribut mainSimulatuer sert � stocker
	 * la r�f�rence sur celui instanci� par la classe MainParking. L'attribut
	 * idTxtCarte : String est le num�ro de la carte en format String
	 * 
	 * La m�thode setMainSimulateur sert � initaliser la variable r�f�rence vers
	 * l'objet mainSimulateur. Cette m�thdoe est appel�e dans la Classe MainParking
	 * pour transmettre un objet mainSimulateur instanci� avec un attribut de type
	 * Stage r�f�ren�ant l'objet primaryStage
	 */
	private MainSimulateur mainSimulateur;
	private String idTxtCarte;

	public Indicateur getIndicateur() {
		return indicateur;
	}

	public void setMainSimulateur(MainSimulateur mainSimulateur) {
		this.mainSimulateur = mainSimulateur;
	}

	public String getIdTxtCarte() {
		return idTxtCarte;
	}

	public void setIdTxtCarte(String idTxtCarte) {
		this.idTxtCarte = idTxtCarte;
	}

	/**
	 * constructeur sans argument
	 */
	public ControleurParking() {

		capteurEntrer = new CapteurEntrer();
		capteurSortir = new CapteurSortir();
		lecteurCarteEntrer = new LecteurEntrer();
		lecteurCarteSortir = new LecteurSortir();
		idCarte = 0;
		barriereEntrer = new BarriereEntrer();
		barriereSortir = new BarriereSortir();
		indicateur = new Indicateur();
		carteSalarieDAO = new CartesalarieDAO();
		carteVisiteurDAO = new CartevisiteurDAO();
		parkingDAO = new ParkingDAO();
	}

	public void setMainCarteSalarie(MainCarteSalarie mainCarteSalarie) { // accesseur MainCarte Salarie
		this.mainCarteSalarie = mainCarteSalarie;
	}

	public void setMainImpression(MainImpression mainImpression) {

		this.mainImpression = mainImpression;
	}

	/**
	 * Cette m�thode est appel�e lors de l'action de clic sur le bouton simulateur.
	 * L'objet mainSimulateur instanci� a comme attribut de type Stage une r�f�rence
	 * sur l'objet primaryStage. L'argument transmis est la r�f�rence vers l'objet
	 * controleurParking en cours d'instance "this" afin d'acc�der aux attributs en
	 * cours par les m�thodes et accesseurs.
	 */
	@FXML
	private void simulateur() {
		mainSimulateur.vueSimulateur(this);
	}

	/**
	 * Etat parking retourne l'etat du parking visiteur a savoir si verif parking =
	 * true alors le parking a des place dispos l'etat indique place disponible
	 * sinon = false il indiquera complet
	 */
	public String etatParking() {
		return indicateur.indiquer(veriPlaceDispoVisiteur());
	}

	/**
	 * Ces m�thodes servent � r�aliser le cas d'utilisation entrer et sont en
	 * int�raction avec le simulateur. La simulateur d�clenche la 1�re m�thode qui
	 * retourne au simulateur l'affichage du lecteur de carte. La 2�me m�thode
	 * obtient l'idCarte. Les arguments transmis sont "this" : la r�f�rence vers
	 * l'objet controleurParking en cours d'instance et "mainSaisieIdCarte" une
	 * r�f�rence vers l'objet qui servira � ouvrir la fen�tre de saisie du num�ro de
	 * la carte. Ensuite ce num�ro de carte est v�rifi� et l'affichage du lecteur de
	 * carte notifiant le r�sultat est retourn� au simulateur. Les m�thodes 3 et 4
	 * concernent l'ouverture et la fermeture de la barri�re.
	 */
	public String uneVoitureArrive1() {
		capteurEntrer.observer(); // met � true l'attribut detecter du capteurEntrer
		return lecteurCarteEntrer.afficherInsererCarte();
	}

	public String uneVoitureArrive2(MainSaisieIdCarte mainSaisieIdCarte) {
		idCarte = lecteurCarteEntrer.lireCarte(this, mainSaisieIdCarte);
		if (verifierCarte(idCarte, false) == false)
			return lecteurCarteEntrer.afficherCarteInvalide();
		else
			return lecteurCarteEntrer.afficherCarteValide();
	}

	public String uneVoitureArrive3() {
		if (barriereEntrer.ouvrir() == false)
			return "Barri�re bloqu�e en position ferm�e";
		else
			return "Barri�re ouverte";
	}

	public String uneVoitureArrive4() {
		capteurEntrer.detecter(); // met � false l'attribut detecter du capteurEntrer
		if (barriereEntrer.fermer() == true)
			return "Barri�re bloqu�e en position ouverte";
		else
			return "";
	}

	/**
	 * Ces m�thode servent � r�aliser le cas d'utilisation sortir et sont en
	 * interaction avec le simulateur. La simulateur d�clenche la 1�re m�thode qui
	 * retourne au simulateur l'affichage du lecteur de carte. La 2�me m�thode
	 * obtient l'idCarte. Les arguments transmis sont "this" : la r�f�rence vers
	 * l'objet controleurParking en cours d'instance et "mainSaisieIdCarte" une
	 * r�f�rence vers l'objet qui servira � ouvrir la fen�tre de saisie du num�ro de
	 * la carte. Ensuite ce num�ro de carte est v�rifi� et l'affichage du lecteur de
	 * carte notifiant le r�sultat est retourn� au simulateur. Les m�thodes 3 e 4
	 * concernent l'ouverture et la fermeture de la barri�re et aussi � inscrire la
	 * date de sortie sur la carte visiteur.
	 */
	public String uneVoitureSort1() {
		capteurSortir.observer(); // met � true l'attribut detecter du capteurSortir
		return lecteurCarteSortir.afficherInsererCarte();
	}

	public String uneVoitureSort2(MainSaisieIdCarte mainSaisieIdCarte) {
		idCarte = lecteurCarteSortir.lireCarte(this, mainSaisieIdCarte);
		if (verifierCarte(idCarte, true) == false)
			return lecteurCarteSortir.afficherCarteInvalide();
		else
			return lecteurCarteSortir.afficherCarteValide();
	}

	public String uneVoitureSort3() {
		if (barriereSortir.ouvrir() == false)
			return "Barri�re bloqu�e en position ferm�e";
		else
			return "Barri�re ouverte";
	}

	public String uneVoitureSort4() {
		capteurSortir.detecter(); // met � false l'attribut detecter du capteurSortir
		if (idCarte >= 100) {
			dateSortieCarteV(idCarte);
			voirToutesLesCartesVisiteurEnCours();
			voirToutesLesCartesVisiteurHistorique();
			indicateurVisiteurEncours();
			indicateurParking();
		}
		if (barriereSortir.fermer() == true)
			return "Barri�re bloqu�e en position ouverte";
		else
			return "";
	}

	/**
	 * Methode qui permet d'ajouter une carte salarie et d'incrementer une place
	 * reserv� salari� et de d�crementer une place reserv�e visiteur
	 * 
	 */
	@FXML
	private void ajouterUneCarteSalarie() {

		mainCarteSalarie.vueCarteSalarie();
		voirToutesLesCarteSalarie();
		indicateurPaceSalarieEncour();
		indicateurPlaceParkingSalarie();

	}

	/**
	 * Methode qui permet de supprimer une carte salarie et de d�crementer une place
	 * reserv� salari� et d'incr�menter une place reserv� visiteur
	 * 
	 */

	@FXML
	private void supprimerCarteSalarie() {

		// affichage d'une fenetre de type "confirmation"
		Alert alert = new Alert(AlertType.CONFIRMATION);
		// titre de la fenetre
		alert.setTitle("Votre attention !");
		// texte affich� dans la fenetre
		alert.setHeaderText("Vous allez Suppimer cette carte salari�");
		alert.setContentText("Confirmez vous cette action ?");
		// affichage de boutons de s�lection et attente de r�ponse de l'utilisateur
		Optional<ButtonType> result = alert.showAndWait();
		// Si bouton "ok" selectionn�
		if (result.get() == ButtonType.OK) {

			Carte carteSalarie = lesCartesSalaries.getSelectionModel().getSelectedItem();
			carteSalarieDAO.supprimerCarte(carteSalarie);

			voirToutesLesCarteSalarie();
			indicateurPaceSalarieEncour();

		}
	}

	/**
	 * Methode qui permet de voir toutes les cartes salari�s
	 */
	@FXML
	public void voirToutesLesCarteSalarie() {
		// remise a zero de l'observable liste
		observableListeCartesSalaries.clear();

		List<Carte> listlesCartesSalaries = carteSalarieDAO.voirLesCartes();

		for (Carte c : listlesCartesSalaries)
			observableListeCartesSalaries.add(c);
	}

	/**
	 * Methode qui permet de voir toutes les cartes salari�s
	 */
	@FXML
	private void voirToutesLesCartesVisiteurHistorique() {
		// remise a zero de l'observable liste
		observableListeCartesVisteursHistorique.clear();

		List<Carte> listlesCartesVisteursHistorique = carteVisiteurDAO.voirLesCartes();
		for (Carte c : listlesCartesVisteursHistorique) {
			if (c.getDateSortie() != null)
				observableListeCartesVisteursHistorique.add(c.vuCarteHistorique());
		}
	}

	/**
	 * Methode qui permet de voir toutes les cartes salari�s
	 */
	@FXML
	private void voirToutesLesCartesVisiteurEnCours() {
		// remise a zero de l'observable liste
		observableListeCartesVisteursEnCours.clear();
		List<Carte> listlesCartesVisteursEnCours = carteVisiteurDAO.voirLesCartes();
		for (Carte c : listlesCartesVisteursEnCours)
			if (c.getDateSortie() == null) {

				observableListeCartesVisteursEnCours.add(c);
			}
	}

	/**
	 * Cette m�thode va appeler la m�thode imprimerCarte dans la classe Dao pour
	 * l'imprission d'une carte salari�
	 * 
	 * 
	 * @return Carte
	 */
	public void imprimerCarteSalarie() {

		Carte carteSalarie = lesCartesSalaries.getSelectionModel().getSelectedItem();
		if (carteSalarie != null) {

			mainImpression.montrerLaCarteParking(carteSalarie);
		}

	}

	/**
	 * Cette m�thode va appeler la m�thode imprimerCarte dans la classe Dao pour
	 * l'imprission d'une carte visiteur
	 * 
	 * 
	 * @return Carte
	 */
	public void imprimerCarteVisiteur() {

		Carte carteVisiteur = lesCartesVisiteursEnCours.getSelectionModel().getSelectedItem();
		if (carteVisiteur != null) {

			mainImpression.montrerLaCarteParking(carteVisiteur);
		}

	}

	/**
	 * cette m�thode permet de demander la possibilit� de cr�er une nouvelle carte
	 * apres avoir verifer qu'il y ai bien des places disponibles avec la methode
	 * veriPlaceDispoVisiteur()
	 * 
	 * visiteur
	 * 
	 * @return boolean
	 */
	@FXML
	public void dmdeCreatCVsiteur() {

		if (veriPlaceDispoVisiteur()) {
			// *********************************************************************************************************************
			// affichage d'une fenetre de type "confirmation"
			Alert alert = new Alert(AlertType.CONFIRMATION);
			// titre de la fenetre
			alert.setTitle("Votre attention !");
			// texte affich� dans la fenetre
			alert.setHeaderText("Vous allez Cr�er Une nouvelle carte Visiteur");
			alert.setContentText("Confirmez vous cette action ?");
			// affichage de boutons de s�lection et attente de r�ponse de l'utilisateur
			Optional<ButtonType> result = alert.showAndWait();
			// Si bouton "ok"
			// selectionn�******************************************************************************************
			if (result.get() == ButtonType.OK) {

				Date dateEntree = new Date(
						(LocalDate.now().toEpochDay() * 24 * 3600 * 1000) + (LocalTime.now().toSecondOfDay() * 1000));

				Date dateSortie = null;

				Cartevisiteur carteVisiteur = new Cartevisiteur(dateEntree, dateSortie);

				carteVisiteurDAO.creerCarte(carteVisiteur);
				voirToutesLesCartesVisiteurEnCours();
				indicateurVisiteurEncours();
				indicateurParking();

			}
		}

	}// loumax :)

	/**
	 * cette m�thode permet de v�rifier le nombre de carte visteur en cours
	 * 
	 * nombreCartesVisiteursEnCours = on liste le nombre de carte dans la table
	 * carte visteur dont la date de sortie est a null list des carte visiteur->
	 * affiche cartes visiteur->compte le nombre carte dont la date de sortie= null;
	 * 
	 * @return int nombreDeCartesVisiteursEnCours
	 */
	@FXML
	public int veriNombreCartesVisiteursEnCour() {

		List<Carte> listCarteVisiteur = carteVisiteurDAO.voirLesCartes();
		int nombreDeCartesVisiteursEnCours = 0;
		for (Carte c : listCarteVisiteur) {

			if (c.getDateSortie() == null) {
				nombreDeCartesVisiteursEnCours++;
			}

		}

		return nombreDeCartesVisiteursEnCours;

	}// loumax :)

	/**
	 * cette methode verifie la disponibilite de places salarie dans la table salarie
	 * par rapport a la table parking
	 * 
	 * verifie le nommbre de carte salarie en cours moins le nombre de place salarie
	 * dans parking
	 * 
	 */

	public boolean veriPlaceDispoSalarie() {
		boolean placeSalarieDisponible = false;
		int nombreDeCartesSalarieEnCours = carteSalarieDAO.voirLesCartes().size();
		nombreDePlaceSalarie = parkingDAO.voirLesPlaceDeParkingSalarie();// place de parking salarie reserv�
		if (nombreDePlaceSalarie - nombreDeCartesSalarieEnCours > 0) {// place salarie en cours
			placeSalarieDisponible = true;
		} else {
			placeSalarieDisponible = false;
		}
		return placeSalarieDisponible;

	}

	/**
	 * cette m�thode permet de v�rifier la disponibilit� du place visiteur
	 * 
	 * on soustr� le nombre de carte visiteurs aux places disponibles si le resultat
	 * est superieur a zero il reste des place visteur disponible
	 * 
	 * @return boolean
	 */
	public boolean veriPlaceDispoVisiteur() {
		boolean placeVisiteurDisponible = false;
		nombreDeCartesVisiteursEnCours = veriNombreCartesVisiteursEnCour();
		nombreDePlaceVisiteur = parkingDAO.voirLesPlaceDeParkingVisiteur();
		nombreDePlaceDispo = parkingDAO.voirLesPlaceDeParkingVisiteur() - veriNombreCartesVisiteursEnCour();
		if (nombreDePlaceDispo > 0)
			placeVisiteurDisponible = true;

		return placeVisiteurDisponible;

	}// loumax :)

	/**
	 * Cette m�thode fait la verification de l'idCarte. Elle utilise le
	 * polymorphisme pour instancier la bonne carte selon l'id. Le boolean est true
	 * s'il s'agit d'une sortie et ne sert que pour le visiteur.
	 * 
	 * @param idCarte
	 * @return boolean
	 */
	public boolean verifierCarte(int idCarte, boolean sortieV) {
		CarteDAO carteLue;
		if (idCarte < 100)
			carteLue = new CartesalarieDAO();
		else
			carteLue = new CartevisiteurDAO();
		return carteLue.verifierCarte(idCarte, sortieV);
	}

	/**
	 * Cette m�thode note la date de sortie sur une carte visiteur
	 * 
	 * @param idCarte
	 */
	public void dateSortieCarteV(int idCarte) {
		carteVisiteurDAO.inscrireDateSortie(idCarte);
	}

	/**
	 * Cr�e l'indiquateur nombre de visiteur en cours
	 */

	public void indicateurVisiteurEncours() {

		nombreDeCartesVisiteursEnCours = veriNombreCartesVisiteursEnCour();

		String nbEncoursVisiteur = Integer.toString(nombreDeCartesVisiteursEnCours);
		nombreTotalvisiteurEnCours.setText(nbEncoursVisiteur);

	}

	/**
	 * Cr�e l'indiquateur etat du parking
	 */

	public void indicateurParking() {

		indiquateurParking = etatParking();
		etatParkingVisiteur.setText(indiquateurParking);

	}

	/**
	 * indicateur place de parking total
	 */
	public void indicateurPlaceParking() {
		nombreDePlaceParking = nombreDePlaceVisiteur + nombreDePlaceSalarie;
		String nbPlaceParking = Integer.toString(nombreDePlaceParking);
		nombreTotalPlaceParking.setText(nbPlaceParking);
	}

	/**
	 * Indicateur des places de parking salarie
	 */
	public void indicateurPlaceParkingSalarie() {
		nombreDePlaceSalarie = parkingDAO.voirLesPlaceDeParkingSalarie();
		String nbPlaceSalarie = Integer.toString(nombreDePlaceSalarie);
		nombreTotalPlaceSalarie.setText(nbPlaceSalarie);
	}

	/**
	 * Indicateur place de parking visiteur
	 */
	public void indicateurPlaceParkingVisiteur() {

		nombreDePlaceVisiteur = parkingDAO.voirLesPlaceDeParkingVisiteur();
		String nbPlaceVisiteur = Integer.toString(nombreDePlaceVisiteur);
		nombreTotalPlaceVisiteur.setText(nbPlaceVisiteur);
	}

	/**
	 * Indicatueur place salarie attibu�
	 */
	public void indicateurPaceSalarieEncour() {
		nombreTotalPlaceSalarieEncours.setText(Integer.toString(carteSalarieDAO.voirLesCartes().size()));
	}

	/**
	 * Methode qui permet d'initialiser tout les valeurs devant etre affich�es au
	 * d�marrage de l'application
	 */

	//////////////////////////////////////////////////////////////////////////////////////////
	@FXML
	private void initialize() {

		lesCartesSalaries.setItems(observableListeCartesSalaries);
		voirToutesLesCarteSalarie();

		lesCartesVisiteursEnCours.setItems(observableListeCartesVisteursEnCours);
		voirToutesLesCartesVisiteurEnCours();

		lesCartesVisiteursHistorique.setItems(observableListeCartesVisteursHistorique);
		voirToutesLesCartesVisiteurHistorique();

		// encours visiteur dans le fxml
		indicateurVisiteurEncours();

		// encours salarie dans le fxml
		indicateurPaceSalarieEncour();

		// etat indicateur parking dans le fxml
		indicateurParking();

		// nombre de place visiteur fxml
		indicateurPlaceParkingVisiteur();

		// nombre de place salarie fxml
		indicateurPlaceParkingSalarie();

		// nombre de place parking
		indicateurPlaceParking();

		// nombre de place salarie en cours
	}

}
