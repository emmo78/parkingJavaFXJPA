package controleur;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * Controleur de la vue du formulaire de saisie du num�ro de la carte. Re�oit par
 * l'accesseur set la r�f�rence du controleurParking instanci� et en cours.
 * 
 * @author Olivier MOREL
 *
 */
public class ControleurSaisieIdCarte {

	private ControleurParking controleurParking;
	@FXML
	private TextField idTxtCarte;
	@FXML
	private Button boutonValiderSaisieId;
	@FXML
	private Button boutonAnnulerSaisieId;

	public ControleurSaisieIdCarte() {
	}

	public void setControleurParking(ControleurParking controleurParking) {
		this.controleurParking = controleurParking;
	}

	@FXML
	private void validerSaisieId() {
		controleurParking.setIdTxtCarte(idTxtCarte.getText());
		Stage stage = (Stage) boutonValiderSaisieId.getScene().getWindow();
		stage.close();
	}

	@FXML
	private void annulerSaisieId() {
		controleurParking.setIdTxtCarte("0");
		Stage stage = (Stage) boutonAnnulerSaisieId.getScene().getWindow();
		stage.close();
	}
}