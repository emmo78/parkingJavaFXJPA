package controleur;

import application.MainSaisieIdCarte;

import javafx.fxml.FXML;

import javafx.scene.control.Button;
import javafx.scene.control.Label;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import javafx.stage.Stage;

/**
 * Controleur de la vue du simulateur
 * 
 * @author Olivier MOREL
 *
 */
public class ControleurSimulateur {
	/**
	 * Attribut pour stocker la r�f�rence vers l'objet controleurParking instanci�
	 * et en cours
	 */
	private ControleurParking controleurParking;

	/**
	 * Attribut pour stocker la r�f�rence sur l'objet de m�me type instanci� par la
	 * classe MainSimulateur et ayant pour attribut une r�f�rence vers l'objet
	 * fenetre (Stage) du simulateur.
	 */
	private MainSaisieIdCarte mainSaisieIdCarte;

	/**
	 * Ces bool�ens servent � activer ou d�sactiver l'action sur un des boutons
	 */
	private boolean boutonVPE;
	private boolean boutonVEE;
	private boolean boutonVPS;
	private boolean boutonVES;
	@FXML
	private Button voiturePresenteEntree; // VPE
	@FXML
	private Button voiturePresenteSortie; // VPS
	@FXML
	private Label lecteurAfficheEntree;
	@FXML
	private Label lecteurAfficheSortie;
	@FXML
	private Rectangle barriereEntree;
	@FXML
	private Rectangle barriereSortie;
	@FXML
	private Button voitureEstEntree; // VEE
	@FXML
	private Button voitureEstSortie; // VES
	@FXML
	private Label indicateurParking;
	@FXML
	private Button fin;

	public ControleurSimulateur() {
		boutonVPE = true;
		boutonVPS = true;
		boutonVEE = false;
		boutonVES = false;
	}

	/**
	 * Accesseur recevant la r�f�rence du controleurParking instanci� et en cours.
	 * 
	 * @param controleurParking
	 */
	public void setControleurParking(ControleurParking controleurParking) {
		this.controleurParking = controleurParking;
	}

	/**
	 * Cet accesseur sert � initaliser la variable r�f�rence vers l'objet
	 * mainSaisieIdCarte. Cette m�thode est appel�e dans la Classe MainSimulateur
	 * pour transmettre un objet mainSaisieIdCarte instanci� avec un attribut de
	 * type Stage r�f�ren�ant l'objet fenetre du simulateur.
	 * 
	 * @param mainSaisieIdCarte
	 */
	public void setMainSaisieIdCarte(MainSaisieIdCarte mainSaisieIdCarte) {
		this.mainSaisieIdCarte = mainSaisieIdCarte;
	}

	/**
	 * Ces 4 m�thodes simulent l'entr�e et la sortie d'un v�hicule dans le parking.
	 * It�ragit avec les m�thodes correspondantes du controleur parking dont la
	 * r�f�rence est transmise en argument.
	 */
	@FXML
	private void voiturePresenteEntree() {
		indicateurParking
				.setText(controleurParking.getIndicateur().indiquer(controleurParking.veriPlaceDispoVisiteur()));
		if (boutonVPE == true) {
			boutonVPE = false;
			lecteurAfficheEntree.setText(controleurParking.uneVoitureArrive1());
			lecteurAfficheEntree.setText(controleurParking.uneVoitureArrive2(mainSaisieIdCarte)); // Le lecteur affiche
																									// un message
			if (lecteurAfficheEntree.getText().compareTo("Carte invalide") == 0) { // le simulateur lit ce message (get)
																					// et agit.
				boutonVPE = true;
				return;
			}
			lecteurAfficheEntree.setText(controleurParking.uneVoitureArrive3());
			if (lecteurAfficheEntree.getText().compareTo("Barri�re bloqu�e en position ferm�e") == 0) {
				boutonVPE = true;
				return;
			}
			barriereEntree.setFill(Color.LAWNGREEN);
			boutonVEE = true;
		}
	}

	@FXML
	private void voitureEstEntree() {
		indicateurParking
				.setText(controleurParking.getIndicateur().indiquer(controleurParking.veriPlaceDispoVisiteur()));
		if (boutonVEE == true) {
			boutonVEE = false;
			lecteurAfficheEntree.setText(controleurParking.uneVoitureArrive4());
			if (lecteurAfficheEntree.getText().compareTo("") == 0)
				barriereEntree.setFill(Color.RED);
			boutonVPE = true;
		}
	}

	@FXML
	private void voiturePresenteSortie() {
		indicateurParking
				.setText(controleurParking.getIndicateur().indiquer(controleurParking.veriPlaceDispoVisiteur()));
		if (boutonVPS == true) {
			boutonVPS = false;
			lecteurAfficheSortie.setText(controleurParking.uneVoitureSort1());
			lecteurAfficheSortie.setText(controleurParking.uneVoitureSort2(mainSaisieIdCarte));
			if (lecteurAfficheSortie.getText().compareTo("Carte invalide") == 0) {
				boutonVPS = true;
				return;
			}
			lecteurAfficheSortie.setText(controleurParking.uneVoitureSort3());
			if (lecteurAfficheSortie.getText().compareTo("Barri�re bloqu�e en position ferm�e") == 0) {
				boutonVPS = true;
				return;
			}
			barriereSortie.setFill(Color.LAWNGREEN);
			boutonVES = true;
		}
	}

	@FXML
	private void voitureEstSortie() {
		indicateurParking
				.setText(controleurParking.getIndicateur().indiquer(controleurParking.veriPlaceDispoVisiteur()));
		if (boutonVES == true) {
			boutonVES = false;
			lecteurAfficheSortie.setText(controleurParking.uneVoitureSort4());
			if (lecteurAfficheSortie.getText().compareTo("") == 0)
				barriereSortie.setFill(Color.RED);
			indicateurParking
					.setText(controleurParking.getIndicateur().indiquer(controleurParking.veriPlaceDispoVisiteur()));
			boutonVPS = true;
		}
	}

	@FXML
	private void fin() {
		Stage stage = (Stage) fin.getScene().getWindow();
		stage.close();
	}

}