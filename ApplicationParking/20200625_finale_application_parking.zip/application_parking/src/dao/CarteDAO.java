package dao;
import java.util.List;

import model.Carte;

/**
 * Interface Carte DAO
 * 
 * pour utiliser le polymorphisme des cartes avec des identifiants de methode commun mais un traitement diff�rent
 * @author Djafri, Tangara, Morel, Sudron
 */

public interface CarteDAO {
	
	/**
	 * Cette m�thode sera appel�e pour cr�er une carte. 
	 * @param carte
	 */
	void creerCarte(Carte carte);
	
	/**
	 * Cette m�thode sera appel�e pour retourner une String de la carte pour que le controleur l'imprime
	 * @param int idCarte
	 * @return Carte 
	 */
	String imprimerCarte(int idCarte);
	
	/**
	 * Cette m�thode sert � v�rifier si une carte est valide. Retourne true si valide sinon false
	 * @param int idCarte
	 * @return boolean
	 */
	boolean verifierCarte(int idCarte, boolean sortieVisiteur);
	
	/**
	 * Cette m�thode pour supprimer une carte. Retourne true si r�ussi sinon false si �chec
	 * @param idCarte
	 * @return boolean
	 */
	void supprimerCarte(Carte carte);
	
	/**
	 * Cette methode retourne une liste des cartes pour que le controlleur puisse affcicher une viewlist
	 * @return List<Carte>
	 */
	List<Carte> voirLesCartes();
	
	/**
	 * methode qui permet de retrouver un objet carte depuis un id en argument
	 * @return Carte
	 *  
	 */
	Carte trouverCarte(int idCarte);
	
	/**
	 * Methode pour inscrire la Date de sortie sur la carte visiteur
	 * @param idCarte
	 */
	void inscrireDateSortie(int idCarte);
	
}
