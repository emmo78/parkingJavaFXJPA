package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import model.Carte;
import model.Cartesalarie;

/**
 * public class CartesalarieDAO implements CarteDAO
 * 
 * Pour l'acc�s aux donn�es des cartes salari�s
 * @author Djafri, Tangara, Morel, Sudron
 *
 */
public class CartesalarieDAO implements CarteDAO {
	
	private EntityManager em;

	/**
	 * Constructeur, instancie l'objet EntityManager pour les transactions.
	 */
	public CartesalarieDAO() {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("application_parking");
		em = factory.createEntityManager();
	}
		
	/**
	 * Methode qui permet de cr�er une carte salarie depuis le controleur
	 * 
	 * @param carteSalarie
	 */
	@Override
	public void creerCarte(Carte carteSalarie) {
		em.getTransaction().begin();
		em.persist(carteSalarie);
		em.getTransaction().commit();
	}
	
	/**
	 * methode qui permet d'imprimer carte depuis le controleur
	 * 
	 */
	@Override
	public String imprimerCarte(int idCarte) {
		Carte carteSalarie=null;
		trouverCarte(idCarte);
		return carteSalarie.toString();
	}

	@Override
	public boolean verifierCarte(int idCarte, boolean sortieV) {
		Cartesalarie cartesalarie;
		em.getTransaction().begin();
		cartesalarie = em.find(Cartesalarie.class, idCarte);
		em.getTransaction().commit();
		if (cartesalarie != null)
			return true;
		else
			return false;
	}

	/**
	 * methode pour trouver une carte salarie avec un type int en argument
	 * 
	 * @return int ou
	 * @return null
	 */
	@Override
	public Carte trouverCarte(int idCarte) {
		Carte carteSalarie;
		em.getTransaction().begin();
		carteSalarie = em.find(Cartesalarie.class, idCarte);
		em.getTransaction().commit();
		if (carteSalarie != null)
			return carteSalarie;
		else
			return null;
	}

	@Override
	public void supprimerCarte(Carte carteSalarie) {
		em.getTransaction().begin();
		em.remove(carteSalarie);
		em.getTransaction().commit();
	}

	@Override
	public List<Carte> voirLesCartes() {
		TypedQuery<Carte> query = em.createQuery("SELECT c FROM Cartesalarie c ORDER BY c.idSalarie", Carte.class);
		List<Carte> liste = query.getResultList();
		return liste;
	}

	@Override
	public void inscrireDateSortie(int idCarte) {
		// TODO Auto-generated method stub
		
	}
}
