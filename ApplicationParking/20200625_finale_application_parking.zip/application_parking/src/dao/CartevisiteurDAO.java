package dao;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import model.Carte;
import model.Cartevisiteur;

/**
 * public class CartevisiteurDAO implements CarteDAO
 * 
 * Pour l'acc�s aux donn�es des cartes visiteurs
 * @author Djafri, Tangara, Morel, Sudron
 *
 */
public class CartevisiteurDAO implements CarteDAO {

	private EntityManager em;

	/**
	 * Constructeur, instancie l'objet EntityManager pour les transactions.
	 */
	public CartevisiteurDAO() {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("application_parking");
		em = factory.createEntityManager();
	}
	
	@Override
	public void creerCarte(Carte carteVisiteur) {
		em.getTransaction().begin();
		em.persist(carteVisiteur);
		em.getTransaction().commit();
	}

	@Override
	public String imprimerCarte(int idCarte) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean verifierCarte(int idCarte, boolean sortieV) {
		Cartevisiteur cartevisiteur;
		em.getTransaction().begin();
		cartevisiteur = em.find(Cartevisiteur.class, idCarte);
		em.getTransaction().commit();
		try { 
			long dateCV = (long)(Math.floor((double)cartevisiteur.getDateEntree().getTime()/(double)(1000*3600*24))); // renvoie la dur�e en j �coul�s depuis le 01 01 1970 ISO
			long date = LocalDate.now().toEpochDay(); // count of days where day 0 is 1970-01-01 (ISO)
			if ((sortieV || dateCV==date) && cartevisiteur.getDateSortie()==null)
				return true;
		}
		catch(NullPointerException e) { 
		}
		return false;
	}

	@Override
	public List<Carte> voirLesCartes() {
		TypedQuery<Carte> query = em.createQuery("SELECT c FROM Cartevisiteur c ORDER BY c.idVisiteur", Carte.class);
		List<Carte> liste = query.getResultList();
		return liste;
	}

	@Override
	public void supprimerCarte(Carte carte) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Carte trouverCarte(int idCarte) {
		Carte carteVisiteur;
		em.getTransaction().begin();
		carteVisiteur = em.find(Cartevisiteur.class, idCarte);
		em.getTransaction().commit();
		if (carteVisiteur != null)
			return carteVisiteur;
		else
			return null;// TODO Auto-generated method stub
	}
	
	@Override
	public void inscrireDateSortie(int idCarte) {
		Carte carteVisiteur;
		em.getTransaction().begin();
		carteVisiteur = em.find(Cartevisiteur.class, idCarte);
		carteVisiteur.setDateSortie(new Date((LocalDate.now().toEpochDay()*24*3600*1000)+(LocalTime.now().toSecondOfDay()*1000)));
		em.getTransaction().commit();
	}
}
