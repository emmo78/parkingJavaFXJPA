package dao;

/**
 * Dao Parking interface pour les requete sql entre le controleur et le model parking
 * 
 * @author Faouzi DJAFRI, Lamaine TANGADA, Olivier MOREL, Sebastien SUDRON
 * 
 */
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Parking;

public class ParkingDAO {

	private EntityManager em;
	private int nombreDePlaceSalarie;

	public ParkingDAO() {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("application_parking");
		em = factory.createEntityManager();
	}

	/**
	 * Methode pour voir les place de parking attribu�es
	 * 
	 */

	public String voirLesPlaceDeParkingAttribue() {

		Parking parking;

		em.getTransaction().begin();
		parking = em.find(Parking.class, 1);
		em.getTransaction().commit();

		int placeS = parking.getNombreDePlaceSalarie();
		int placeV = parking.getNombreDePlaceVisiteur();

		String voirLesPlacesReserves = "Nombre de place Parking reserv� aux salari�s \t" + placeS
				+ "\n Nombre de place Parking reserv� aux Visiteurs \t" + placeV;

		return voirLesPlacesReserves;
	}// Loumax :)

	/**
	 * Methode pour voir les places de parking visiteur
	 * 
	 */
	public int voirLesPlaceDeParkingVisiteur() {

		Parking parking;

		em.getTransaction().begin();
		parking = em.find(Parking.class, 1);
		em.getTransaction().commit();

		int nombrePlaceVisiteur = parking.getNombreDePlaceVisiteur();

		return nombrePlaceVisiteur;
	}// Loumax :)

	/**
	 * Methode pour voir les places de parking visiteur
	 * 
	 */
	public int voirLesPlaceDeParkingSalarie() {

		Parking parking;

		em.getTransaction().begin();
		parking = em.find(Parking.class, 1);
		em.getTransaction().commit();

		int nombrePlaceSalarie = parking.getNombreDePlaceSalarie();

		return nombrePlaceSalarie;
	}// Loumax :)

}