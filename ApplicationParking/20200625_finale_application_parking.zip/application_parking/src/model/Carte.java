package model;

import java.util.Date;

/**
 * Cette interface n'est que pour le polymorphisme des Cartes
 * @author Djafri, Tangara, Morel, Sudron
 *
 */
public interface Carte {
	
	public int getId();

	public void setId(int id);

	public String getDepartement();

	public void setDepartement(String departement);

	public String getNom();

	public void setNom(String nom);
	
	public Date getDateEntree();

	public void setDateEntree(Date dateEntree);

	public Date getDateSortie();

	public void setDateSortie(Date dateSortie);
	
	/**
	 * vu pour les carte encours
	 * 
	 */

	public String toString();
	
	public String vuCarteHistorique();
	
}