package model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;


/**
 * The persistent class for the cartesalarie database table.
 * 
 */
@Entity
@NamedQuery(name="Cartesalarie.findAll", query="SELECT c FROM Cartesalarie c")
public class Cartesalarie implements Serializable, Carte {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idSalarie;

	private String departement;

	private String nom;

	/**
	 * Constructeur de la class carteSalarie sans arguments
	 * 
	 */
	public Cartesalarie() {
	}

	/**
	 * Constructeur de la class carteSalarie avec en argument
	 * 
	 */
	public Cartesalarie(String departement, String nom) {
		this.departement = departement;
		this.nom = nom;
	}
	
	@Override
	public int getId() {
		return this.idSalarie;
	}

	@Override
	public void setId(int idSalarie) {
		this.idSalarie = idSalarie;
	}

	@Override
	public String getDepartement() {
		return this.departement;
	}

	@Override
	public void setDepartement(String departement) {
		this.departement = departement;
	}

	@Override
	public String getNom() {
		return this.nom;
	}

	@Override
	public void setNom(String nom) {
		this.nom = nom;
	}

	@Override
	public Date getDateEntree() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setDateEntree(Date dateEntree) {
		// TODO Auto-generated method stub
	}

	@Override
	public Date getDateSortie() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setDateSortie(Date dateSortie) {
		// TODO Auto-generated method stub
	}
	
	@Override
	public String toString() {
		 
		  
		String vu =     " Salari� n�  "+ getId() +"\t"+getNom() + " D�partement N� : " + departement  ;
		return vu;	}

	@Override
	public String vuCarteHistorique() {
		// TODO Auto-generated method stub
		return null;
	}


}