package model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the cartevisiteur database table.
 * 
 */
@Entity
@NamedQuery(name="Cartevisiteur.findAll", query="SELECT c FROM Cartevisiteur c")
public class Cartevisiteur implements Serializable, Carte {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idVisiteur;

	@Temporal(TemporalType.TIMESTAMP)
	private Date dateEntree;

	@Temporal(TemporalType.TIMESTAMP)
	private Date dateSortie;

	public Cartevisiteur() {
	}
	
	/**
	 * Constructeur avec argument date Entree et dateSortie a null
	 */
	public Cartevisiteur(Date dateEntree,Date dateSortie) {
		
		this.dateEntree=dateEntree;
		this.dateSortie=dateSortie;
	}

	public int getId() {
		return this.idVisiteur;
	}

	public void setId(int idVisiteur) {
		this.idVisiteur = idVisiteur;
	}

	public Date getDateEntree() {
		return this.dateEntree;
	}

	public void setDateEntree(Date dateEntree) {
		this.dateEntree = dateEntree;
	}

	public Date getDateSortie() {
		return this.dateSortie;
	}

	public void setDateSortie(Date dateSortie) {
		this.dateSortie = dateSortie;
	}

	@Override
	public String getDepartement() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setDepartement(String departement) {
		// TODO Auto-generated method stub
	}

	@Override
	public String getNom() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setNom(String nom) {
		// TODO Auto-generated method stub
	}
	
	@Override
	public String toString() {
		return " Visiteur N� " + idVisiteur + " Entr� le : " + dateToString(dateEntree);
	}
	 		
	public String vuCarteHistorique() {
		return " Visiteur N� " + idVisiteur + " Entr� le " + dateToString(dateEntree) + " Sortie le " + dateToString(dateSortie);
	}
	
	private String dateToString(Date date) {
		return LocalDateTime.ofEpochSecond(date.getTime()/1000, 0, ZoneOffset.of("Z")).format(DateTimeFormatter.ofPattern("dd/MM/yyyy - HH:mm:ss")).toString();
	}
}