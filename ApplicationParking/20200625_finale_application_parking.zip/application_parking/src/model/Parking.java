package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the parking database table.
 * 
 */
@Entity
@NamedQuery(name="Parking.findAll", query="SELECT p FROM Parking p")
public class Parking implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private int nombreDePlaceSalarie;

	private int nombreDePlaceVisiteur;

	public Parking() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getNombreDePlaceSalarie() {
		return this.nombreDePlaceSalarie;
	}

	public void setNombreDePlaceSalarie(int nombreDePlaceSalarie) {
		this.nombreDePlaceSalarie = nombreDePlaceSalarie;
	}

	public int getNombreDePlaceVisiteur() {
		return this.nombreDePlaceVisiteur;
	}

	public void setNombreDePlaceVisiteur(int nombreDePlaceVisiteur) {
		this.nombreDePlaceVisiteur = nombreDePlaceVisiteur;
	}

	@Override
	public String toString() {
		return "Parking [id=" + id + ", nombreDePlaceSalarie=" + nombreDePlaceSalarie + ", nombreDePlaceVisiteur="
				+ nombreDePlaceVisiteur + "]";
	}

}