/**
 * 
 */
package test_JUnit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import vue.BarriereSortir;

/**
 * @author Djafri, Tangara, Morel, Sudron
 *
 */
public class BarriereSortirTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link vue.BarriereSortir#ouvrir()}.
	 */
	@Test
	public void testOuvrir() {
		BarriereSortir barriereSortie = new BarriereSortir();
		assertTrue(barriereSortie.ouvrir());
	}

	/**
	 * Test method for {@link vue.BarriereSortir#fermer()}.
	 */
	@Test
	public void testFermer() {
		BarriereSortir barriereSortie = new BarriereSortir();
		assertFalse(barriereSortie.fermer());
	}

}
