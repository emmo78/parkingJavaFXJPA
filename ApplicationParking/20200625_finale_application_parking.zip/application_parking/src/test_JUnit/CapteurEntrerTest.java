/**
 * 
 */
package test_JUnit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import vue.CapteurEntrer;

/**
 * @author Djafri, Tangara, Morel, Sudron
 *
 */
public class CapteurEntrerTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link vue.CapteurEntrer#observer()}.
	 */
	@Test
	public void testObserver() {
		CapteurEntrer capteurEntrer = new CapteurEntrer();
		assertTrue(capteurEntrer.observer());
	}

	/**
	 * Test method for {@link vue.CapteurEntrer#detecter()}.
	 */
	@Test
	public void testDetecter() {
		CapteurEntrer capteurEntrer = new CapteurEntrer();
		assertFalse(capteurEntrer.detecter());
	}

}
