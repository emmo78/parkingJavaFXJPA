/**
 * 
 */
package test_JUnit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import dao.CartesalarieDAO;
import model.Cartesalarie;

/**
 * @author Djafri, Tangara, Morel, Sudron
 *
 */
public class CartesalarieDAOTest {



	/**
	 * Test method for {@link dao.CartesalarieDAO#verifierCarte(int, boolean)}.
	 */
	@Test
	public void testVerifierCarte() {
		CartesalarieDAO cartesalarieDAO = new CartesalarieDAO();
		assertTrue(cartesalarieDAO.verifierCarte(91,true));
	}

	/**
	 * Test method for {@link dao.CartesalarieDAO#trouverCarte(int)}.
	 */
	@Test
	public void testTrouverCarte() {
		CartesalarieDAO cartesalarieDAO = new CartesalarieDAO();
		assertNotNull(cartesalarieDAO.trouverCarte(91));
	}

	

	/**
	 * Test method for {@link dao.CartesalarieDAO#voirLesCartes()}.
	 */
	@Test
	public void testVoirLesCartes() {
		CartesalarieDAO cartesalarieDAO = new CartesalarieDAO();
		assertNotNull(cartesalarieDAO.voirLesCartes());
	}

	
}
