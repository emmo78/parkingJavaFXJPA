/**
 * 
 */
package test_JUnit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import dao.CartevisiteurDAO;

/**
 * @author Djafri, Tangara, Morel, Sudron
 *
 */
public class CartevisiteurDAOTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link dao.CartevisiteurDAO#creerCarte(model.Carte)}.
	 */
	@Test
	public void testCreerCarte() {
		CartevisiteurDAO cartevisiteurDAO = new CartevisiteurDAO();
		//assertTrue(cartevisiteurDAO.creerCarte());
	}


	/**
	 * Test method for {@link dao.CartevisiteurDAO#verifierCarte(int, boolean)}.
	 */
	@Test
	public void testVerifierCarte() {
		CartevisiteurDAO cartevisiteurDAO = new CartevisiteurDAO ();
		assertTrue(cartevisiteurDAO.verifierCarte(109,true));
	}

	/**
	 * Test method for {@link dao.CartevisiteurDAO#voirLesCartes()}.
	 */
	@Test
	public void testVoirLesCartes() {
		CartevisiteurDAO cartevisiteurDAO = new CartevisiteurDAO();
		assertNotNull(cartevisiteurDAO.voirLesCartes());
	}


	/**
	 * Test method for {@link dao.CartevisiteurDAO#trouverCarte(int)}.
	 */

	@Test
	public void testTrouverCarte() {
		CartevisiteurDAO cartevisiteurDAO = new CartevisiteurDAO();
		assertNotNull(cartevisiteurDAO.trouverCarte(110));
	}

}
