/**
 * 
 */
package test_JUnit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import controleur.ControleurParking;

/**
 * @author Djafri, Tangara, Morel, Sudron
 *
 */
public class ControleurParkingTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link controleur.ControleurParking#veriPlaceDispoVisiteur()}.
	 */
	@Test
	public void testVeriPlaceDispoVisiteur() {
		ControleurParking controleurParking = new ControleurParking();
		assertTrue(controleurParking.veriPlaceDispoVisiteur());
	}
	/**
	 * Test method for {@link controleur.ControleurParking#etatParking()}.
	 */
	@Test
	public void testEtatParking() {
		ControleurParking controleurParking = new ControleurParking();
		assertTrue("test",controleurParking.veriPlaceDispoVisiteur());
	}

	/**
	 * Test method for {@link controleur.ControleurParking#veriNombreCartesVisiteursEnCour()}.
	 */
	@Test
	public void testVeriNombreCartesVisiteursEnCour() {
		ControleurParking controleurParking = new ControleurParking();
		assertEquals(1,controleurParking.veriNombreCartesVisiteursEnCour());
	}

	/**
	 * Test method for {@link controleur.ControleurParking#veriPlaceDispoSalarie()}.
	 */
	@Test
	public void testVeriPlaceDispoSalarie() {
		ControleurParking controleurParking = new ControleurParking();
		assertTrue(controleurParking.veriPlaceDispoSalarie());
	}



	/**
	 * Test method for {@link controleur.ControleurParking#verifierCarte(int, boolean)}.
	 */
	@Test
	public void testVerifierCarte() {
		ControleurParking controleurParking = new ControleurParking();
		assertTrue(controleurParking.verifierCarte(110,true));
	}



}
