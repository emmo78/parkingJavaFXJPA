package vue;

public abstract class Barriere {

	private boolean ouvert;
	
	public Barriere() {
		ouvert=false;
	}

	/**
	 * m�thode qui permet de ouvrir la barriere 
	 * @return boolean
	 */
	public abstract boolean ouvrir ();
	
	/**
	 * m�thode qui permet de fermer la barriere   
	 * @return boolean 
	 */
	public abstract boolean fermer();

	/**
	 * Questionne l'�tat de la barri�re
	 * @return
	 */
	public boolean isOuvert() {
		return ouvert;
	}
	
	/**
	 * Fixe l'�tat de la boarri�re
	 * @param ouvert
	 */
	public void setOuvert(boolean ouvert) {
		this.ouvert = ouvert;
	}

	
}