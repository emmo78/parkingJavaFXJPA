package vue;

public class BarriereEntrer extends Barriere{

	public BarriereEntrer() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public boolean ouvrir() {
		this.setOuvert(true);
		return this.isOuvert();
	}

	@Override
	public boolean fermer() {
		this.setOuvert(false);
		return this.isOuvert();
	}

}
