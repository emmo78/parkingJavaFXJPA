package vue;

public class BarriereSortir extends Barriere{

	public BarriereSortir() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public boolean ouvrir() {
		this.setOuvert(true);
		return this.isOuvert();
	}

	@Override
	public boolean fermer() {
		this.setOuvert(false);
		return this.isOuvert();
	}


}

