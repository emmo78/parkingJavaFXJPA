package vue;
/**
 * cette classe avec une seule m�thode permet de detecter une voiture 
 * @author djafri,tangara,sudron,morel
 *
 */
public abstract class Capteur {
	
	private boolean detecte;
	
	public Capteur() {
		detecte = false;
	}

	/**
	 * Cette m�thode observe la pr�sentation d'un v�hicule ici simul�
	 * @return
	 */
	public abstract boolean observer();
	
	/**
	 * cette m�thode observe si une voiture est pr�sente
	 * @return void
	 */
	public abstract boolean detecter();
	
	public boolean isDetecte() {
		return detecte;
	}

	public void setDetecte(boolean detecte) {
		this.detecte = detecte;
	}

}
