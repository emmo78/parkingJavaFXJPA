package vue;

public class CapteurEntrer extends Capteur{

	public CapteurEntrer() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Cette classe serait les conditions r�elles avec un vrai d�tecteur. L� c'est juste simul�.
	 */
	@Override
	public boolean observer() {
		this.setDetecte(true);
		return this.isDetecte();
	}
	
	@Override
	public boolean detecter() {
		this.setDetecte(false);
		return this.isDetecte();
	}


}
