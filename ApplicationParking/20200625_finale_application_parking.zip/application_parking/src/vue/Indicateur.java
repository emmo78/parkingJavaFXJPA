package vue;

/**
 * cette classe permet d'indiquer qi le parking est complet ou non pour les
 * visiteurs
 * 
 * @author djafri,tangara,sudron,morel
 *
 */
public class Indicateur {

	/**
	 * m�thode indiquant le nombre de place disponible avec un parametre P1
	 * 
	 * @param p1
	 */
	public String indiquer(boolean isPlaceVDispo) {
		if (isPlaceVDispo == true)
			return "Place disponible";
		else
			return "Parking complet";
	}
}
