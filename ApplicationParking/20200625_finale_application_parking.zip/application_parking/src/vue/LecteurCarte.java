package vue;

import application.MainSaisieIdCarte;
import controleur.ControleurParking;

/**
 * classe abstraite que est �tendue par les deux classes filles a savoir
 * lecteurEntrer et lecteurSortir
 * 
 * @author djafri,tangara,sudron,morel
 *
 */
public abstract class LecteurCarte {

	private int numeroCarte;

	public LecteurCarte() {
	}

	public abstract String afficherInsererCarte();

	public abstract String afficherCarteInvalide();
	
	public abstract String afficherCarteValide();
	
	/**
	 * La m�thode lireCarte extrait le num�ro de carte dans le lecteur.
	 * Ici simul�e par l'entr�e manuelle d'un num�ro de carte.
	 *  
	 * @return
	 */
	public abstract int lireCarte(ControleurParking controleurParking, MainSaisieIdCarte mainSaisieIdCarte);
	
	public int getNumeroCarte() {
		return numeroCarte;
	}

	public void setNumeroCarte(int numeroCarte) {
		this.numeroCarte = numeroCarte;
	}
}
