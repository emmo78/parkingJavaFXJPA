package vue;

import application.MainSaisieIdCarte;
import controleur.ControleurParking;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class LecteurEntrer extends LecteurCarte{

	public LecteurEntrer() {
	  }

	@Override
	public String afficherInsererCarte() {
		return "Bonjour, veuillez ins�rer votre carte";
	}
	
	@Override
	public String afficherCarteInvalide() {
		return ("Carte invalide");
	}
	
	@Override
	public String afficherCarteValide() {
		return ("Carte valide");
	}
	
	@Override
	public int lireCarte(ControleurParking controleurParking, MainSaisieIdCarte mainSaisieIdCarte) {
		boolean b;
		do {
			b=false;
			mainSaisieIdCarte.vueSaisieIdCarte(controleurParking);
			try {
				this.setNumeroCarte(Integer.parseInt(controleurParking.getIdTxtCarte()));
			} catch (NumberFormatException e) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("Probl�me sur la saisie IdCarte");
				alert.setHeaderText("Entrer un entier ou annuler");	
				alert.showAndWait();
				b=true;
			}
		} while (b);
		return this.getNumeroCarte();
	}

}
