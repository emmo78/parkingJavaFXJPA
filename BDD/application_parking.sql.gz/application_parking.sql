-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 25 juin 2020 à 00:21
-- Version du serveur :  10.4.11-MariaDB
-- Version de PHP : 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `application_parking`
--
CREATE DATABASE IF NOT EXISTS `application_parking` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `application_parking`;

-- --------------------------------------------------------

--
-- Structure de la table `cartesalarie`
--

CREATE TABLE `cartesalarie` (
  `idSalarie` int(11) NOT NULL,
  `nom` char(50) NOT NULL,
  `departement` char(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `cartesalarie`
--

INSERT INTO `cartesalarie` (`idSalarie`, `nom`, `departement`) VALUES
(1, 'Tintin', '77'),
(4, 'seb', '78');

-- --------------------------------------------------------

--
-- Structure de la table `cartevisiteur`
--

CREATE TABLE `cartevisiteur` (
  `idVisiteur` int(11) NOT NULL,
  `dateEntree` datetime DEFAULT NULL,
  `dateSortie` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `cartevisiteur`
--

INSERT INTO `cartevisiteur` (`idVisiteur`, `dateEntree`, `dateSortie`) VALUES
(100, '2020-05-18 22:22:27', '2020-05-18 22:23:02'),
(101, '2020-05-18 22:22:30', '2020-05-18 22:23:29');

-- --------------------------------------------------------

--
-- Structure de la table `parking`
--

CREATE TABLE `parking` (
  `id` int(11) NOT NULL,
  `nombreDePlaceVisiteur` int(11) NOT NULL,
  `nombreDePlaceSalarie` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `parking`
--

INSERT INTO `parking` (`id`, `nombreDePlaceVisiteur`, `nombreDePlaceSalarie`) VALUES
(1, 4, 10);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `cartesalarie`
--
ALTER TABLE `cartesalarie`
  ADD PRIMARY KEY (`idSalarie`);

--
-- Index pour la table `cartevisiteur`
--
ALTER TABLE `cartevisiteur`
  ADD PRIMARY KEY (`idVisiteur`);

--
-- Index pour la table `parking`
--
ALTER TABLE `parking`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `cartesalarie`
--
ALTER TABLE `cartesalarie`
  MODIFY `idSalarie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `cartevisiteur`
--
ALTER TABLE `cartevisiteur`
  MODIFY `idVisiteur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
